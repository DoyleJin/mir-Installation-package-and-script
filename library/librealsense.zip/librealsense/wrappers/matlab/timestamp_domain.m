classdef timestamp_domain < int64
    enumeration
        hardware_clock  (0)
        system_time     (1)
        count           (2)
    end
end