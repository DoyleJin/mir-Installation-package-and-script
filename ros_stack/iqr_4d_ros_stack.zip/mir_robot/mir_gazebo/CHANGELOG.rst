^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package mir_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.2 (2018-07-30)
------------------
* mir_gazebo: Install config directory
* Contributors: Martin Günther

1.0.1 (2018-07-17)
------------------
* gazebo: Replace robot_pose_ekf with robot_localization
  robot_pose_ekf is deprecated, and has been removed from the navigation
  stack starting in melodic.
* gazebo: Adjust ekf.yaml
* gazebo: Copy robot_localization/ekf_template.yaml
  ... for modification.
* Contributors: Martin Günther

1.0.0 (2018-07-12)
------------------
* Initial release
* Contributors: Martin Günther
