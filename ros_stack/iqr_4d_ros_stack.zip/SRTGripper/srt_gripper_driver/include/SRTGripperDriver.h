/**********************************************************************************
** MIT License
** 
** Copyright (c) 2019 I-Quotient-Robotics https://github.com/I-Quotient-Robotics
**
** Permission is hereby granted, free of charge, to any person obtaining a copy
** of this software and associated documentation files (the "Software"), to deal
** in the Software without restriction, including without limitation the rights
** to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
** copies of the Software, and to permit persons to whom the Software is
** furnished to do so, subject to the following conditions:
** 
** The above copyright notice and this permission notice shall be included in all
** copies or substantial portions of the Software.
** 
** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
** IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
** FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
** AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
** LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
** OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
** SOFTWARE.
*********************************************************************************/
#ifndef SRTGRIPPERDRIVER_H
#define SRTGRIPPERDRIVER_H
#include <iostream>
#include <sstream>
#include "QSerialPort.h"

constexpr auto SLEEP_TIME_MS = 100;
typedef int SRTPressure;
typedef uint8_t byte;

namespace IQR
{

class SRTGripperDriver
{
public:
  SRTGripperDriver(const std::string &portName);
  ~SRTGripperDriver();

  bool openGripper();
  bool openGripper(const unsigned int &gears);
  bool closeGripper();
  bool closeGripper(const unsigned int &gears);
  bool releaseGripper();

  SRTPressure getOpenPressure() const;
  SRTPressure getClosePressure() const;
  bool setOpenPressure(const SRTPressure &openPressure);
  bool setClosePressure(const SRTPressure &closePressure);

  unsigned short getOpenDelay() const;
  unsigned short getCloseDelay() const;
  bool setOpenDelay(const unsigned short &delayMs);
  bool setCloseDelay(const unsigned short &delayMs);

  SRTPressure getOpenGearsPressure(const unsigned int &gears) const;
  SRTPressure getCloseGearsPressure(const unsigned int &gears) const;
  bool setOpenGearsPressure(const unsigned int &gears, const SRTPressure &gearsPressure);
  bool setCloseGearsPressure(const unsigned int &gears, const SRTPressure &gearsPressure);

  SRTPressure getNowPressure() const;
  unsigned int getWorkCount() const;
  std::string getControlBoxVersion() const;

private:
  QSerialPort *_com;
};
} // namespace IQR

#endif //SRTGRIPPERDRIVER_H
