/**********************************************************************************
** MIT License
** 
** Copyright (c) 2019 I-Quotient-Robotics https://github.com/I-Quotient-Robotics
**
** Permission is hereby granted, free of charge, to any person obtaining a copy
** of this software and associated documentation files (the "Software"), to deal
** in the Software without restriction, including without limitation the rights
** to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
** copies of the Software, and to permit persons to whom the Software is
** furnished to do so, subject to the following conditions:
** 
** The above copyright notice and this permission notice shall be included in all
** copies or substantial portions of the Software.
** 
** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
** IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
** FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
** AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
** LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
** OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
** SOFTWARE.
*********************************************************************************/
#include <iostream>
#include <ros/ros.h>
#include <ros/time.h>

#include "SRTGripperDriver.h"
#include "srt_gripper_driver/SRTGripperCmd.h"
#include "srt_gripper_driver/SRTGripperStatus.h"

using namespace std;

class SRTGripperDriverNode
{
public:
  SRTGripperDriverNode();
  ~SRTGripperDriverNode();
  void pubGripperStatus();

protected:
  void callBack(const srt_gripper_driver::SRTGripperCmd &msg);
private:
  IQR::SRTGripperDriver *_gr;
  std::string _portName;
  ros::NodeHandle _nh;
	ros::Subscriber _cmdSub;
	ros::Publisher _statusPub;
};

SRTGripperDriverNode::SRTGripperDriverNode()
  :_nh("~")
{
  //init params
  _nh.param<std::string>("port_name", _portName, "/dev/ttyUSB0");

  //set subscriber
  _statusPub = _nh.advertise<srt_gripper_driver::SRTGripperStatus>("srt_gripper_status", 50);
  //set publisher
  _cmdSub = _nh.subscribe("srt_gripper_cmd", 50, &SRTGripperDriverNode::callBack, this);

  cout << "griapper port name:" << _portName << endl;
  _gr = new IQR::SRTGripperDriver(_portName);
  sleep(2);
}

SRTGripperDriverNode::~SRTGripperDriverNode( )
{
  delete _gr;
}

void SRTGripperDriverNode::pubGripperStatus()
{
  srt_gripper_driver::SRTGripperStatus msg;
  msg.nowPressure = _gr->getNowPressure();
  msg.workCount = _gr->getWorkCount();
  _statusPub.publish(msg);
}

void SRTGripperDriverNode::callBack(const srt_gripper_driver::SRTGripperCmd &msg)
{
  if(msg.openFlage)
  {
    _gr->openGripper();
  }
  if(msg.closeFlage)
  {
    if(_gr->closeGripper())
      std::cout << "close" << endl;
  }
  else
  {
    std::cout << "close flage false" << endl;
  }
  
  if(msg.releaseFlage)
  {
    _gr->releaseGripper();
  }
  std::cout << "SRTGripperDriverNode::callBack" << endl;
}



int main(int argc, char *argv[])
{
  ros::init(argc, argv, "SRTGripperDriverNode");

  SRTGripperDriverNode nd;
  ros::Rate r(10);

	while (ros::ok())
	{
		ros::spinOnce();
    nd.pubGripperStatus();
		r.sleep();
	}
  return 0;
}