/**********************************************************************************
** MIT License
** 
** Copyright (c) 2019 I-Quotient-Robotics https://github.com/I-Quotient-Robotics
**
** Permission is hereby granted, free of charge, to any person obtaining a copy
** of this software and associated documentation files (the "Software"), to deal
** in the Software without restriction, including without limitation the rights
** to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
** copies of the Software, and to permit persons to whom the Software is
** furnished to do so, subject to the following conditions:
** 
** The above copyright notice and this permission notice shall be included in all
** copies or substantial portions of the Software.
** 
** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
** IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
** FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
** AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
** LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
** OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
** SOFTWARE.
*********************************************************************************/

#include "SRTGripperDriver.h"

IQR::SRTGripperDriver::SRTGripperDriver(const std::string & portName)
{
  _com = new QSerialPort(portName,
    QSerialPort::Baud38400,
    QSerialPort::Data8,
    QSerialPort::OneStop,
    QSerialPort::NoParity,
    QSerialPort::NoFlowControl);
  _com->open(QSerialPort::ReadAndWrite);
  if (_com->getError())
  {
    std::cout << "open serial error code:" << _com->getError() << std::endl;
  }
}

IQR::SRTGripperDriver::~SRTGripperDriver()
{
  delete _com;
}

bool IQR::SRTGripperDriver::openGripper()
{
  if (_com->isOpen())
  {
    byte msg[4] = { 0xFB, 0x00, 0xFF, 0xFF };
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS*1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    for (size_t i = 0; i < 4; i++)
    {
      if (!(buf[i] == msg[i]))
        return false;
    }
    return true;
  }
  else
    return false;
}

bool IQR::SRTGripperDriver::openGripper(const unsigned int & gears)
{
  if (_com->isOpen())
  {
    byte _gears = 0x00;
    switch (gears)
    {
    case 0: _gears = 0x00; break;
    case 1: _gears = 0x01; break;
    case 2: _gears = 0x02; break;
    case 3: _gears = 0x03; break;
    case 4: _gears = 0x04; break;
    case 5: _gears = 0x05; break;
    case 6: _gears = 0x06; break;
    case 7: _gears = 0x07; break;
    case 8: _gears = 0x08; break;
    case 9: _gears = 0x09; break;
    default:
      return false;
      break;
    }

    byte msg[4] = { 0xFB, 0x00, 0xFF, 0xFF };
    msg[1] = _gears;
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    for (size_t i = 0; i < 4; i++)
    {
      if (!(buf[i] == msg[i]))
        return false;
    }
    return true;
  }
  else
    return false;
}

bool IQR::SRTGripperDriver::closeGripper()
{
  if (_com->isOpen())
  {
    byte msg[4] = { 0xFA, 0x00, 0xFF, 0xFF };
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    for (size_t i = 0; i < 4; i++)
    {
      if (!(buf[i] == msg[i]))
        return false;
    }
    return true;
  }
  else
    return false;

}

bool IQR::SRTGripperDriver::closeGripper(const unsigned int & gears)
{
  if (_com->isOpen())
  {
    byte _gears = 0x00;
    switch (gears)
    {
    case 0: _gears = 0x00; break;
    case 1: _gears = 0x01; break;
    case 2: _gears = 0x02; break;
    case 3: _gears = 0x03; break;
    case 4: _gears = 0x04; break;
    case 5: _gears = 0x05; break;
    case 6: _gears = 0x06; break;
    case 7: _gears = 0x07; break;
    case 8: _gears = 0x08; break;
    case 9: _gears = 0x09; break;
    default:
      return false;
      break;
    }

    byte msg[4] = { 0xFA, 0x00, 0xFF, 0xFF };
    msg[1] = _gears;
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    for (size_t i = 0; i < 4; i++)
    {
      if (!(buf[i] == msg[i]))
        return false;
    }
    return true;
  }
  else
    return false;
}

bool IQR::SRTGripperDriver::releaseGripper()
{
  if (_com->isOpen())
  {
    byte msg[4] = { 0xFC, 0xFF, 0xFF, 0xFF };
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    for (size_t i = 0; i < 4; i++)
    {
      if (!(buf[i] == msg[i]))
        return false;
    }
    return true;
  }
  else
    return false;
}

SRTPressure IQR::SRTGripperDriver::getOpenPressure() const
{
  if (_com->isOpen())
  {
    byte msg[4] = { 0xAB, 0xFF, 0xFF, 0x16 };
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    if ((buf[0] & 0xAB) && (buf[3] & 0x16))
    {
      if (buf[1] == 0x00)
      {
        return SRTPressure(buf[2]);
      }
      else if (buf[1] == 0x11)
      {
        return -SRTPressure(buf[2]);
      }
    }
    else
    {
      return -999;
    }
  }
  else
    return -999;
}

SRTPressure IQR::SRTGripperDriver::getClosePressure() const
{
  if (_com->isOpen())
  {
    byte msg[4] = { 0xAA, 0xFF, 0xFF, 0x16 };
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    if ((buf[0] & 0xAA) && (buf[3] & 0x16))
    {
      if (buf[1] == 0x00)
      {
        return SRTPressure(buf[2]);
      }
      else if (buf[1] == 0x11)
      {
        return -SRTPressure(buf[2]);
      }
    }
    else
    {
      return -999;
    }
  }
  else
    return -999;
}

bool IQR::SRTGripperDriver::setOpenPressure(const SRTPressure & openPressure)
{
  // open: -75kpa <  pressure < 0kpa
  if (openPressure > 0 && openPressure < -70)
    return false;

  if (_com->isOpen())
  {
    byte msg[4] = { 0xEB, 0x11, 0x00, 0x16 };
    msg[2] = (byte)(0xff & abs(openPressure));
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    for (size_t i = 0; i < 4; i++)
    {
      if (!(buf[i] == msg[i]))
        return false;
    }
    return true;
  }
  else
    return false;
}

bool IQR::SRTGripperDriver::setClosePressure(const SRTPressure & closePressure)
{
  // close: 0kpa <  pressure < 100kpa
  if (closePressure < 0 && closePressure > 95)
    return false;

  if (_com->isOpen())
  {
    byte msg[4] = { 0xEA, 0x00, 0x00, 0x16 };
    msg[2] = (byte)(0xff & closePressure);
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    for (size_t i = 0; i < 4; i++)
    {
      if (!(buf[i] == msg[i]))
        return false;
    }
    return true;
  }
  else
    return false;
}

unsigned short IQR::SRTGripperDriver::getOpenDelay() const
{
  if (_com->isOpen())
  {
    byte msg[4] = { 0xDB, 0xAF, 0xFF, 0xFF };
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    if ((buf[0] == 0xDB) && (buf[1] == 0xAF))
    {
      unsigned short delayMs = buf[3];
      delayMs |= (buf[2] << 8);
      return delayMs;
    }
    else
    {
      return -1;
    }
  }
  else
    return -1;
}

unsigned short IQR::SRTGripperDriver::getCloseDelay() const
{
  if (_com->isOpen())
  {
    byte msg[4] = { 0xDA, 0xAF, 0xFF, 0xFF };
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    if ((buf[0] == 0xDA) && (buf[1] == 0xAF))
    {
      unsigned short delayMs = buf[3];
      delayMs |= (buf[2] << 8);
      return delayMs;
    }
    else
    {
      return -1;
    }
  }
  else
    return -1;
}

bool IQR::SRTGripperDriver::setOpenDelay(const unsigned short & delayMs)
{
  if (delayMs < 0 && delayMs > 60000)
    return false;

  if (_com->isOpen())
  {
    byte msg[4] = { 0xDB, 0xEA, 0x00, 0x00 };
    msg[3] = (0xff & delayMs);
    msg[2] = ((0xff00 & delayMs) >> 8);
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    for (size_t i = 0; i < 4; i++)
    {
      if (!(buf[i] == msg[i]))
        return false;
    }
    return true;
  }
  else
    return false;
}

bool IQR::SRTGripperDriver::setCloseDelay(const unsigned short & delayMs)
{
  if (delayMs < 0 && delayMs > 60000)
    return false;

  if (_com->isOpen())
  {
    byte msg[4] = { 0xDA, 0xEA, 0x00, 0x00 };
    msg[3] = (0xff & delayMs);
    msg[2] = ((0xff00 & delayMs) >> 8);
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    for (size_t i = 0; i < 4; i++)
    {
      if (!(buf[i] == msg[i]))
        return false;
    }
    return true;
  }
  else
    return false;
}

bool IQR::SRTGripperDriver::setOpenGearsPressure(const unsigned int & gears, const SRTPressure & gearsPressure)
{
  // open: -75kpa <  pressure < 0kpa
  if (gearsPressure > 0 && gearsPressure < -70)
    return false;

  if (_com->isOpen())
  {
    byte _gears = 0x00;
    switch (gears)
    {
    case 1: _gears = 0x01; break;
    case 2: _gears = 0x02; break;
    case 3: _gears = 0x03; break;
    case 4: _gears = 0x04; break;
    case 5: _gears = 0x05; break;
    case 6: _gears = 0x06; break;
    case 7: _gears = 0x07; break;
    case 8: _gears = 0x08; break;
    case 9: _gears = 0x09; break;
    default: return false; break;
    }

    byte msg[4] = { 0xF9, 0x00, 0x00, 0x16 };
    msg[1] = (_gears);
    msg[2] = (0xff & abs(gearsPressure));
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    for (size_t i = 0; i < 4; i++)
    {
      if (!(buf[i] == msg[i]))
        return false;
    }
    return true;
  }
  else
    return false;
}

bool IQR::SRTGripperDriver::setCloseGearsPressure(const unsigned int & gears, const SRTPressure & gearsPressure)
{
  // close: 0kpa <  pressure < 100kpa
  if (gearsPressure < 0 && gearsPressure > 95)
    return false;

  if (_com->isOpen())
  {
    byte _gears = 0x00;
    switch (gears)
    {
    case 1: _gears = 0x01; break;
    case 2: _gears = 0x02; break;
    case 3: _gears = 0x03; break;
    case 4: _gears = 0x04; break;
    case 5: _gears = 0x05; break;
    case 6: _gears = 0x06; break;
    case 7: _gears = 0x07; break;
    case 8: _gears = 0x08; break;
    case 9: _gears = 0x09; break;
    default: return false; break;
    }

    byte msg[4] = { 0xF8, 0x00, 0x00, 0x16 };
    msg[1] = (_gears);
    msg[2] = (0xff & abs(gearsPressure));
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    for (size_t i = 0; i < 4; i++)
    {
      if (!(buf[i] == msg[i]))
        return false;
    }
    return true;
  }
  else
    return false;
}

SRTPressure IQR::SRTGripperDriver::getOpenGearsPressure(const unsigned int & gears) const
{
  if (_com->isOpen())
  {
    byte _gears = 0x00;
    switch (gears)
    {
    case 1: _gears = 0x01; break;
    case 2: _gears = 0x02; break;
    case 3: _gears = 0x03; break;
    case 4: _gears = 0x04; break;
    case 5: _gears = 0x05; break;
    case 6: _gears = 0x06; break;
    case 7: _gears = 0x07; break;
    case 8: _gears = 0x08; break;
    case 9: _gears = 0x09; break;
    default:
      return -999;
      break;
    }

    byte msg[4] = { 0xF5, 0x00, 0xFF, 0x16 };
    msg[1] = _gears;
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    if ((buf[0] & msg[0]) && (buf[1] & msg[1]) && (buf[3] & msg[3]))
    {
      return -SRTPressure(buf[2]);
    }
    else
    {
      return -999;
    }
  }
  else
    return -999;
}

SRTPressure IQR::SRTGripperDriver::getCloseGearsPressure(const unsigned int & gears) const
{
  if (_com->isOpen())
  {
    byte _gears = 0x00;
    switch (gears)
    {
    case 1: _gears = 0x01; break;
    case 2: _gears = 0x02; break;
    case 3: _gears = 0x03; break;
    case 4: _gears = 0x04; break;
    case 5: _gears = 0x05; break;
    case 6: _gears = 0x06; break;
    case 7: _gears = 0x07; break;
    case 8: _gears = 0x08; break;
    case 9: _gears = 0x09; break;
    default:
      return -999;
      break;
    }

    byte msg[4] = { 0xF4, 0x00, 0xFF, 0x16 };
    msg[1] = _gears;
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    if ((buf[0] & msg[0]) && (buf[1] & msg[1]) && (buf[3] & msg[3]))
    {
      return SRTPressure(buf[2]);
    }
    else
    {
      return -999;
    }
  }
  else
    return -999;
}

SRTPressure IQR::SRTGripperDriver::getNowPressure() const
{
  if (_com->isOpen())
  {
    byte msg[4] = { 0xA9, 0xFF, 0xFF, 0x16 };
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    if ((buf[0] == 0xA9) && (buf[3] == 0x16))
    {
      if (buf[1] == 0x00)
      {
        return SRTPressure(buf[2]);
      }
      else if (buf[1] == 0x11)
      {
        return -SRTPressure(buf[2]);
      }
    }
    else
    {
      return -999;
    }
  }
  else
    return -999;
}

unsigned int IQR::SRTGripperDriver::getWorkCount() const
{
  if (_com->isOpen())
  {
    byte msg[4] = { 0xCC, 0xFF, 0xFF, 0xFF };
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[6] = { 0, };
    _com->read(buf, 6);
    if (buf[0] == 0xCC && buf[1] == 0xFF)
    {
      unsigned int count = buf[5];
      count |= (buf[4] << 8);
      count |= (buf[3] << 16);
      count |= (buf[2] << 24);
      return count;
    }
    else
    {
      return -999;
    }
  }
  else
    return -999;
}

std::string IQR::SRTGripperDriver::getControlBoxVersion() const
{
  if (_com->isOpen())
  {
    byte msg[4] = { 0x33, 0xFF, 0xFF, 0xFF };
    _com->write(msg, 4);
#if defined(_WIN32)
    Sleep(SLEEP_TIME_MS);
#else
    usleep(SLEEP_TIME_MS * 1000);
#endif
    byte buf[4] = { 0, };
    _com->read(buf, 4);
    if ((byte)buf[0] == 0x33)
    {
      std::stringstream ss;
      ss << 'v' << int(buf[1]) << '.' << int(buf[2]) << '.' << int(buf[3]);
      return ss.str();
    }
    else
    {
      return NULL;
    }
  }
  else
    return NULL;
}
