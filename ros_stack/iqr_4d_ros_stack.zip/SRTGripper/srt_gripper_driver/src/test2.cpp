#include <iostream>
#if defined(_WIN32)
#include <windows.h>
#else
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>
#include <linux/serial.h>
#endif
#include "SRTGripperDriver.h"
#include "QSerialPort.h"


using namespace std;
typedef uint8_t byte;

int main(int argv, char *argc[])
{

  //QUart com("/dev/ttyUSB0", 38400);
  // QSerialPort com("/dev/ttyUSB1", 
  //                 QSerialPort::Baud38400,
  //                 QSerialPort::Data8,
  //                 QSerialPort::OneStop,
  //                 QSerialPort::NoParity,
  //                 QSerialPort::NoFlowControl);
  // cout << com.getError() << endl;
  // com.open(QSerialPort::ReadAndWrite);
  // cout << com.getError() << endl;
  // com.setBaudRate(QSerialPort::Baud38400);
  // cout << com.getError() << endl;
  // com.setDataBits(QSerialPort::Data8);
  // cout << com.getError() << endl;
  // com.setParity(QSerialPort::NoParity);
  // cout << com.getError() << endl;
  // com.setStopBits(QSerialPort::OneStop);
  // cout << com.getError() << endl;
  // com.setFlowControl(QSerialPort::NoFlowControl);
  // cout << com.getError() << endl;



  // sleep(1);

  // byte msg[4] = {0xFA, 0x00, 0xFF, 0xFF};
  // int64_t len = com.write(msg, 4);

  // cout << "len:" << len << endl;

  // sleep(1);

  IQR::SRTGripperDriver gr("/dev/ttyUSB1");

  sleep(1);

  if(gr.closeGripper())
  {
    sleep(1);
  }
  else
  {
    cout << "error" << endl;
  }

  sleep(1);
  gr.releaseGripper();
  //cout << "close pressure:" << gr.getClosePressure() << endl;



  // if (gr.releaseGripper())
  // {
  //   cout << "release successful" << endl;
  //   sleep(1);
  // }
  //Sleep(2000);

  //if (gr.closeGripper(1))
  //{
  //  cout << "close successful" << endl;
  //Sleep(2000);
  //}

  //if (gr.openGripper(2))
  //{
  //  cout << "open successful" << endl;
  //Sleep(2000);
  //}

  //for (size_t i = 0; i < 10; i++)
  //{
  //  cout << ":" << gr.getNowPressure() << endl;
  //  Sleep(1000);
  //}

  //if (gr.getClosePressure())
  //{
  //  cout << "close pressure:" << gr.getClosePressure() << endl;
  //  Sleep(2000);
  //}
  //

  //if (gr.getOpenPressure())
  //{
  //  cout << "open pressure:"<< gr.getOpenPressure() << endl;
  //  Sleep(2000);
  //}

  //if (gr.setClosePressure(70))
  //{
  //  cout << "set close pressure:70" << endl;
  //  Sleep(2000);
  //}

  //if (gr.setOpenPressure(-40))
  //{
  //  cout << "set open pressure:-40" << endl;
  //  Sleep(2000);
  //}

  //if (gr.getClosePressure())
  //{
  //  cout << "close pressure:" << gr.getClosePressure() << endl;
  //  Sleep(2000);
  //}

  //if (gr.getOpenPressure())
  //{
  //  cout << "open pressure:" << gr.getOpenPressure() << endl;
  //  Sleep(2000);
  //}

  //cout << "close delay:" << gr.getCloseDelay() << endl;
  //Sleep(2000);
  //cout << "open delay:" << gr.getOpenDelay() << endl;
  //Sleep(2000);
  //if (gr.setCloseDelay(3000))
  //{
  //  cout << "set close delay:" << 3000 << endl;
  //  Sleep(2000);
  //}
  //if (gr.setOpenDelay(4000))
  //{
  //  cout << "set open delay:" << 4000 << endl;
  //  Sleep(2000);
  //}
  //cout << "close delay:" << gr.getCloseDelay() << endl;
  //Sleep(2000);
  //cout << "open delay:" << gr.getOpenDelay() << endl;
  //Sleep(2000);

  //for (size_t i = 1; i < 10; i++)
  //{
  //  cout << "Open " << i << " GearsPressure:" << gr.getOpenGearsPressure(i) << endl;
  //  Sleep(1000);
  //}
  //for (size_t i = 1; i < 10; i++)
  //{
  //  int p = i * -7;
  //  if (gr.setOpenGearsPressure(i, p))
  //  {
  //    cout << "set open " << i << " GearsPressure:" << p << endl;
  //    Sleep(1000);
  //  }
  //}
  //for (size_t i = 1; i < 10; i++)
  //{
  //  cout << "Open " << i << " GearsPressure:" << gr.getOpenGearsPressure(i) << endl;
  //  Sleep(1000);
  //}

  //for (size_t i = 1; i < 10; i++)
  //{
  //  cout << "Close " << i << " GearsPressure:" << gr.getCloseGearsPressure(i) << endl;
  //  Sleep(1000);
  //}
  //for (size_t i = 1; i < 10; i++)
  //{
  //  int p = i * 9;
  //  if (gr.setCloseGearsPressure(i, p))
  //  {
  //    cout << "set Close " << i << " GearsPressure:" << p << endl;
  //    Sleep(1000);
  //  }
  //}
  //for (size_t i = 1; i < 10; i++)
  //{
  //  cout << "Close " << i << " GearsPressure:" << gr.getCloseGearsPressure(i) << endl;
  //  Sleep(1000);
  //}

  //for (size_t i = 1; i < 10; i++)
  //{
  //  gr.closeGripper(i);
  //  Sleep(2000);
  //  cout << "now pressure:" << gr.getNowPressure() << endl;
  //  Sleep(2000);
  //}

  //for (size_t i = 1; i < 10; i++)
  //{
  //  gr.openGripper(i);
  //  Sleep(2000);
  //  cout << "now pressure:" << gr.getNowPressure() << endl;
  //  Sleep(2000);
  //}

  // if (gr.closeGripper())
  // {
  //   cout << "close grapper" << endl;
  //   sleep(2);
  // }

  // if (gr.openGripper())
  // {
  //   cout << "open grapper" << endl;
  //   sleep(2);
  // }

  // if (gr.releaseGripper())
  // {
  //   cout << "release successful" << endl;
  //   sleep(1);
  // }

  // if (gr.closeGripper(5))
  // {
  //   cout << "close grapper 5" << endl;
  //   sleep(2);
  // }

  // if (gr.openGripper(3))
  // {
  //   cout << "open grapper 3" << endl;
  //   sleep(2);
  // }

  // if (gr.releaseGripper())
  // {
  //   cout << "release successful" << endl;
  //   sleep(1);
  // }

  // cout << gr.getControlBoxVersion();

  return 0;
}